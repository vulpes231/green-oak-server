const allowedOrigins = [
  "http://localhost:5173",
  "http://localhost:3600",
  "https://regentoak.us",
  "https://admin.regentoak.us",
];

module.exports = allowedOrigins;
